#include "main.h"
#include "INS_Task.h"
#include "try_try.h"
#include "FreeRTos.h"
#include "cmsis_os.h"
#include "bmi088driver.h"
#include "ist8310driver.h"
#include "AHRS.h"
extern osThreadId try_tryHandle;

void Try_Try(void const * argument){		
	BMI088_init();
	ist8310_init();
	while(1)
	{
	BMI088_read(bmi088_real_data.gyro, bmi088_real_data.accel, &bmi088_real_data.temp);
    //rotate and zero drift 
	//    imu_cali_slove(INS_gyro_1, INS_accel_1, INS_mag_1, &bmi088_real_data_1, &ist8310_real_data_1);
	//   AHRS_init(INS_quat_1, INS_accel_1, INS_mag_1);
		vTaskDelay(5);
	}
}
