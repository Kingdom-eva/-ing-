angle_clc/user_lib.o: ..\angle_clcgroup\algorithm\user_lib.c \
  ..\angle_clcgroup\algorithm\user_lib.h \
  ..\angle_clcgroup\APP\struct_typedef.h \
  D:\Keil5_ARM\ARM\CMSIS-DSP\1.16.2\Include\arm_math.h \
  D:\Keil5_ARM\ARM\CMSIS-DSP\1.16.2\Include\arm_math_types.h \
  ..\Drivers\CMSIS\Include\cmsis_compiler.h \
  ..\Drivers\CMSIS\Include\cmsis_armclang.h \
  D:\Keil5_ARM\ARM\CMSIS-DSP\1.16.2\Include\arm_math_memory.h \
  D:\Keil5_ARM\ARM\CMSIS-DSP\1.16.2\Include\dsp\none.h \
  D:\Keil5_ARM\ARM\CMSIS-DSP\1.16.2\Include\dsp\utils.h \
  D:\Keil5_ARM\ARM\CMSIS-DSP\1.16.2\Include\dsp\basic_math_functions.h \
  D:\Keil5_ARM\ARM\CMSIS-DSP\1.16.2\Include\dsp\interpolation_functions.h \
  D:\Keil5_ARM\ARM\CMSIS-DSP\1.16.2\Include\dsp\bayes_functions.h \
  D:\Keil5_ARM\ARM\CMSIS-DSP\1.16.2\Include\dsp\statistics_functions.h \
  D:\Keil5_ARM\ARM\CMSIS-DSP\1.16.2\Include\dsp\fast_math_functions.h \
  D:\Keil5_ARM\ARM\CMSIS-DSP\1.16.2\Include\dsp\matrix_functions.h \
  D:\Keil5_ARM\ARM\CMSIS-DSP\1.16.2\Include\dsp\complex_math_functions.h \
  D:\Keil5_ARM\ARM\CMSIS-DSP\1.16.2\Include\dsp\controller_functions.h \
  D:\Keil5_ARM\ARM\CMSIS-DSP\1.16.2\Include\dsp\support_functions.h \
  D:\Keil5_ARM\ARM\CMSIS-DSP\1.16.2\Include\dsp\distance_functions.h \
  D:\Keil5_ARM\ARM\CMSIS-DSP\1.16.2\Include\dsp\svm_functions.h \
  D:\Keil5_ARM\ARM\CMSIS-DSP\1.16.2\Include\dsp\svm_defines.h \
  D:\Keil5_ARM\ARM\CMSIS-DSP\1.16.2\Include\dsp\transform_functions.h \
  D:\Keil5_ARM\ARM\CMSIS-DSP\1.16.2\Include\dsp\filtering_functions.h \
  D:\Keil5_ARM\ARM\CMSIS-DSP\1.16.2\Include\dsp\quaternion_math_functions.h \
  D:\Keil5_ARM\ARM\CMSIS-DSP\1.16.2\Include\dsp\window_functions.h
