angle_clc/detect_task.o: ..\angle_clcgroup\TASK\detect_task.c \
  ..\angle_clcgroup\TASK\detect_task.h \
  ..\angle_clcgroup\APP\struct_typedef.h \
  ..\Middlewares\Third_Party\FreeRTOS\Source\CMSIS_RTOS\cmsis_os.h \
  ..\Middlewares\Third_Party\FreeRTOS\Source\include\FreeRTOS.h \
  ..\Core\Inc\FreeRTOSConfig.h \
  ..\Middlewares\Third_Party\FreeRTOS\Source\include\projdefs.h \
  ..\Middlewares\Third_Party\FreeRTOS\Source\include\portable.h \
  ..\Middlewares\Third_Party\FreeRTOS\Source\include\deprecated_definitions.h \
  ..\Middlewares\Third_Party\FreeRTOS\Source\portable\RVDS\ARM_CM4F\portmacro.h \
  ..\Middlewares\Third_Party\FreeRTOS\Source\include\mpu_wrappers.h \
  ..\Middlewares\Third_Party\FreeRTOS\Source\include\task.h \
  ..\Middlewares\Third_Party\FreeRTOS\Source\include\list.h \
  ..\Middlewares\Third_Party\FreeRTOS\Source\include\timers.h \
  ..\Middlewares\Third_Party\FreeRTOS\Source\include\queue.h \
  ..\Middlewares\Third_Party\FreeRTOS\Source\include\semphr.h \
  ..\Middlewares\Third_Party\FreeRTOS\Source\include\event_groups.h
