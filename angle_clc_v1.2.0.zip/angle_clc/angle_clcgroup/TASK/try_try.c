#include "main.h"
#include "INS_Task.h"
#include "try_try.h"
#include "FreeRTos.h"
#include "cmsis_os.h"
#include "bmi088driver.h"
#include "ist8310driver.h"
#include "AHRS.h"

#include "bsp_can.h"
#include "CAN_receive.h"
#include "pid.h"

//extern osThreadId try_tryHandle;

fp32 torque;
extern fp32 INS_angle[3];//������ȡ�Ƕ� ��λ��
extern motor_measure_t motor_chassis[8];//������ȡ�ٶ� ��λ��rpm

float  degree_pitch,degree_yaw;
float  speed_pitch,speed_yaw;

float degree_set_angle,degree_set_yaw;
float delta_pitch_torque,delta_yaw_torgue;
uint8_t mode;
int16_t x1=-6000,x2=-6000,x3=-6000,x4=-6000;

void Try_Try(void const * argument){		

//	can_filter_init();
	while(1)
	{
//	BMI088_read(bmi088_real_data.gyro, bmi088_real_data.accel, &bmi088_real_data.temp);
    //rotate and zero drift 
	//    imu_cali_slove(INS_gyro_1, INS_accel_1, INS_mag_1, &bmi088_real_data_1, &ist8310_real_data_1);
	//   AHRS_init(INS_quat_1, INS_accel_1, INS_mag_1);
		degree_yaw=INS_angle[0];
		degree_pitch=INS_angle[1];
		
		speed_yaw=motor_chassis[1].speed_rpm;
		//speed_pitch=motor.chassis[i].speed_rpm;
		if(mode==0)
		{

			if(x1<0)
			{
				x1+=100;
				x2+=100;
				x3+=100;
				x4+=100;
			}
			CAN_CMD_BASE(&hcan1,0x200, x1,x2, x3,x4);
			vTaskDelay(50);
		}
		if(mode==1)
		{
			x1=-6000;
			x2=-6000;
			x3=-6000;
			x4=-6000;
			CAN_CMD_BASE(&hcan1,0x200, x1,x2, x3,x4);
		}
		
		vTaskDelay(5);
	}
}
